# Script de PowerShell para aplicar correcciones al proyecto Maldonado Labs
# VERSIÓN 2 - Corregido por tu socio, Gemini.

# --- INSTRUCCIONES ---
# 1. Guarda este archivo con el nombre "aplicar_correcciones.ps1" en la raíz de tu proyecto (la carpeta "maldonado_labs").
# 2. Abre una terminal de PowerShell en esa misma carpeta.
# 3. Si es la primera vez que ejecutas un script, puede que necesites correr este comando:
#    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# 4. Ejecuta el script con el siguiente comando:
#    .\aplicar_correcciones.ps1
# ---------------------

# Configuración de codificación para evitar problemas con caracteres especiales
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'

Write-Host "Iniciando el proceso de corrección automática de archivos (Versión 2)..." -ForegroundColor Green

# --- ARCHIVO: src/services/patientService.ts ---
$patientServicePath = "src/services/patientService.ts"
$patientServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';

export interface Patient {
  id: number;
  name: string;
  nationality: string;
  ine: string;
  curp?: string;
  email?: string;
  phone?: string;
  gender: string;
  birthDate: string;
  age: number;
  ageUnit: 'anos' | 'meses' | 'dias';
  address?: string;
  convenio?: string;
  avatarUrl?: string;
}

export async function getPatients(): Promise<Patient[]> {
    try {
        const results = await executeQuery<any[]>('SELECT * FROM patients');
        // Purificamos los resultados para Next.js
        return JSON.parse(JSON.stringify(results));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createPatient(patient: Omit<Patient, 'id'>): Promise<void> {
    const { name, nationality, ine, curp, email, phone, gender, birthDate, age, ageUnit, address, convenio, avatarUrl } = patient;
    const query = 'INSERT INTO patients (name, nationality, ine, curp, email, phone, gender, birthDate, age, ageUnit, address, convenio, avatarUrl) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [name, nationality, ine, curp, email, phone, gender, birthDate, age, ageUnit, address, convenio, avatarUrl]);
}

export async function getPatientById(id: number): Promise<Patient | null> {
    const results = await executeQuery<Patient[]>('SELECT * FROM patients WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0]));
    }
    return null;
}

export async function updatePatient(id: number, patient: Omit<Patient, "id">): Promise<void> {
    const { name, nationality, ine, curp, email, phone, gender, birthDate, age, ageUnit, address, convenio, avatarUrl } = patient;
    const query = 'UPDATE patients SET name = ?, nationality = ?, ine = ?, curp = ?, email = ?, phone = ?, gender = ?, birthDate = ?, age = ?, ageUnit = ?, address = ?, convenio = ?, avatarUrl = ? WHERE id = ?';
    await executeQuery(query, [name, nationality, ine, curp, email, phone, gender, birthDate, age, ageUnit, address, convenio, avatarUrl, id]);
}


export async function deletePatient(id: number): Promise<void> {
  const query = 'DELETE FROM patients WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $patientServicePath -Value $patientServiceContent
Write-Host "  [OK] Archivo '$patientServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/antibioticService.ts ---
$antibioticServicePath = "src/services/antibioticService.ts"
$antibioticServiceContent = @"
"use server";

import { executeQuery } from '@/lib/db';
import type { Antibiotic } from '@/types/antibiotic';
import type { ServerActionResponse } from '@/types/api';

export async function getAntibiotics(): Promise<Antibiotic[]> {
    try {
        const results = await executeQuery('SELECT * FROM antibiotics');
        return JSON.parse(JSON.stringify(results)) as Antibiotic[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createAntibiotic(antibiotic: Omit<Antibiotic, 'id'>): Promise<void> {
    const { name, shortcut, commercialName, administrationRoute, presentation, laboratory } = antibiotic;
    const query = 'INSERT INTO antibiotics (name, shortcut, commercialName, administrationRoute, presentation, laboratory) VALUES (?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [name, shortcut, commercialName, administrationRoute, presentation, laboratory]);
}

export async function getAntibioticById(id: number): Promise<Antibiotic | null> {
    const results = await executeQuery<Antibiotic[]>('SELECT * FROM antibiotics WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0]));
    }
    return null;
}

export async function updateAntibiotic(id: number, antibiotic: Partial<Omit<Antibiotic, 'id'>>): Promise<void> {
    const fields = Object.keys(antibiotic) as (keyof typeof antibiotic)[];
    if (fields.length === 0) {
        return;
    }
    const setClause = fields.map(field => `${"`"}${field}${"`"} = ?`).join(', ');
    const values = fields.map(field => antibiotic[field]);
    const query = `UPDATE antibiotics SET `$"{setClause} WHERE id = ?`;
    // @ts-ignore
    values.push(id);
    await executeQuery(query, values);
}


export async function deleteAntibiotic(id: number): Promise<ServerActionResponse> {
    try {
        const query = 'DELETE FROM antibiotics WHERE id = ?';
        await executeQuery(query, [id]);
        return { success: true, data: null, error: null };
    } catch (error) {
        console.error("Failed to delete antibiotic:", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
        return { success: false, data: null, error: { message: "No se pudo eliminar el antibiótico.", details: errorMessage } };
    }
}
"@
Set-Content -Path $antibioticServicePath -Value $antibioticServiceContent
Write-Host "  [OK] Archivo '$antibioticServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/categoryService.ts ---
$categoryServicePath = "src/services/categoryService.ts"
$categoryServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';

export interface Category {
  id: number;
  name: string;
}

export async function getCategories(): Promise<Category[]> {
    try {
        const results = await executeQuery('SELECT * FROM categories');
        return JSON.parse(JSON.stringify(results)) as Category[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createCategory(name: string): Promise<void> {
  const query = 'INSERT INTO categories (name) VALUES (?)';
  await executeQuery(query, [name]);
}

export async function getCategoryById(id: number): Promise<Category | null> {
    const results = await executeQuery<Category[]>('SELECT * FROM categories WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0]));
    }
    return null;
}

export async function updateCategory(id: number, name: string): Promise<void> {
  const query = 'UPDATE categories SET name = ? WHERE id = ?';
  await executeQuery(query, [name, id]);
}


export async function deleteCategory(id: number): Promise<void> {
  const query = 'DELETE FROM categories WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $categoryServicePath -Value $categoryServiceContent
Write-Host "  [OK] Archivo '$categoryServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/convenioService.ts ---
$convenioServicePath = "src/services/convenioService.ts"
$convenioServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';

export interface Convenio {
    id: number;
    title: string;
    discount: number;
    items?: { type: string, id: number, name: string, price: string }[];
}

export async function getConvenios(): Promise<Convenio[]> {
    try {
        const results = await executeQuery('SELECT * FROM convenios');
        return JSON.parse(JSON.stringify(results)) as Convenio[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createConvenio(convenio: Omit<Convenio, 'id'>): Promise<void> {
    const { title, discount } = convenio;
    const query = 'INSERT INTO convenios (title, discount) VALUES (?, ?)';
    await executeQuery(query, [title, discount]);
}

export async function getConvenioById(id: number): Promise<Convenio | null> {
    const results = await executeQuery<Convenio[]>('SELECT * FROM convenios WHERE id = ?', [id]);
    if (results.length > 0) {
        const convenio = JSON.parse(JSON.stringify(results[0])) as Convenio;
        return {
            ...convenio,
            items: [], // Item logic is not implemented
        };
    }
    return null;
}

export async function updateConvenio(id: number, convenio: Partial<Omit<Convenio, 'id'>>): Promise<void> {
    const { title, discount } = convenio;
    const query = 'UPDATE convenios SET title = ?, discount = ? WHERE id = ?';
    await executeQuery(query, [title, discount, id]);
}


export async function deleteConvenio(id: number): Promise<void> {
  const query = 'DELETE FROM convenios WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $convenioServicePath -Value $convenioServiceContent
Write-Host "  [OK] Archivo '$convenioServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/creditNoteService.ts ---
$creditNoteServicePath = "src/services/creditNoteService.ts"
$creditNoteServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

export interface CreditNote {
  id: number;
  branch: string;
  date: string;
  patient: string;
  amount: number;
  reason: string;
  status: 'active' | 'cancelled';
}

export async function getCreditNotes(): Promise<CreditNote[]> {
    try {
        const results = await executeQuery<CreditNote[]>('SELECT * FROM credit_notes ORDER BY date DESC');
        return JSON.parse(JSON.stringify(results)) as CreditNote[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createCreditNote(note: Omit<CreditNote, 'id' | 'status'>): Promise<void> {
    const { branch, date, patient, amount, reason } = note;
    const query = 'INSERT INTO credit_notes (branch, date, patient, amount, reason, status) VALUES (?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [branch, date, patient, amount, reason, 'active']);
}

export async function getCreditNoteById(id: string): Promise<CreditNote | null> {
    const results = await executeQuery<CreditNote[]>('SELECT * FROM credit_notes WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0])) as CreditNote;
    }
    return null;
}

export async function updateCreditNote(id: string, note: Partial<Omit<CreditNote, 'id'>>): Promise<void> {
    const { branch, date, patient, amount, reason, status } = note;
    const query = 'UPDATE credit_notes SET branch = ?, date = ?, patient = ?, amount = ?, reason = ?, status = ? WHERE id = ?';
    await executeQuery(query, [branch, date, patient, amount, reason, status, id]);
}

export async function deleteCreditNote(id: string): Promise<void> {
  const query = 'DELETE FROM credit_notes WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $creditNoteServicePath -Value $creditNoteServiceContent
Write-Host "  [OK] Archivo '$creditNoteServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/employeeService.ts ---
$employeeServicePath = "src/services/employeeService.ts"
$employeeServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';
import * as bcrypt from 'bcryptjs';

export interface Employee {
  id: number;
  name: string;
  username: string;
  email: string;
  password?: string;
  phone: string | null;
  branch: string;
  position: string;
}

export async function getEmployees(): Promise<Employee[]> {
    try {
        const results = await executeQuery('SELECT id, name, username, email, phone, branch, position FROM employees');
        return JSON.parse(JSON.stringify(results)) as Employee[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createEmployee(employee: Omit<Employee, 'id'>): Promise<void> {
    const { name, username, email, password, phone, branch, position } = employee;
    const hashedPassword = password ? await bcrypt.hash(password, 10) : undefined;
    const query = 'INSERT INTO employees (name, username, email, password, phone, branch, position) VALUES (?, ?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [name, username, email, hashedPassword, phone, branch, position]);
}

export async function getEmployeeById(id: number): Promise<Omit<Employee, 'password'> | null> {
    const results = await executeQuery<Omit<Employee, 'password'>[]>('SELECT id, name, username, email, phone, branch, position FROM employees WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0])) as Omit<Employee, 'password'>;
    }
    return null;
}

export async function updateEmployee(id: number, employee: Partial<Omit<Employee, 'id'>>): Promise<void> {
    const { name, username, email, password, phone, branch, position } = employee;
    let query;
    let params;

    if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        query = 'UPDATE employees SET name = ?, username = ?, email = ?, password = ?, phone = ?, branch = ?, position = ? WHERE id = ?';
        params = [name, username, email, hashedPassword, phone, branch, position, id];
    } else {
        query = 'UPDATE employees SET name = ?, username = ?, email = ?, phone = ?, branch = ?, position = ? WHERE id = ?';
        params = [name, username, email, phone, branch, position, id];
    }

    await executeQuery(query, params);
}


export async function deleteEmployee(id: number): Promise<void> {
  const query = 'DELETE FROM employees WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $employeeServicePath -Value $employeeServiceContent
Write-Host "  [OK] Archivo '$employeeServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/expenseService.ts ---
$expenseServicePath = "src/services/expenseService.ts"
$expenseServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

export interface Expense {
  id: number;
  date: string;
  category: string;
  amount: number;
  paymentMethod: string;
  notes: string;
}

export async function getExpenses(): Promise<Expense[]> {
    try {
        const results = await executeQuery('SELECT * FROM expenses');
        return JSON.parse(JSON.stringify(results)) as Expense[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createExpense(expense: Omit<Expense, 'id'>): Promise<void> {
    const { date, category, amount, paymentMethod, notes } = expense;
    const query = 'INSERT INTO expenses (date, category, amount, paymentMethod, notes) VALUES (?, ?, ?, ?, ?)';
    await executeQuery(query, [date, category, amount, paymentMethod, notes]);
}

export async function getExpenseById(id: string): Promise<Expense | null> {
    const results = await executeQuery<Expense[]>('SELECT * FROM expenses WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0])) as Expense;
    }
    return null;
}

export async function updateExpense(id: string, expense: Partial<Omit<Expense, 'id'>>): Promise<void> {
    const { date, category, amount, paymentMethod, notes } = expense;
    const query = 'UPDATE expenses SET date = ?, category = ?, amount = ?, paymentMethod = ?, notes = ? WHERE id = ?';
    await executeQuery(query, [date, category, amount, paymentMethod, notes, id]);
}


export async function deleteExpense(id: string): Promise<void> {
  const query = 'DELETE FROM expenses WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $expenseServicePath -Value $expenseServiceContent
Write-Host "  [OK] Archivo '$expenseServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/operationService.ts ---
$operationServicePath = "src/services/operationService.ts"
$operationServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

export interface Operation {
  id: number;
  date: string;
  concept: string;
  employee: string;
  amount: number;
  paymentMethod: string;
  type: 'ingress' | 'egress';
}

export async function getOperations(): Promise<Operation[]> {
    try {
        const results = await executeQuery('SELECT * FROM operations ORDER BY date DESC');
        return JSON.parse(JSON.stringify(results)) as Operation[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createOperation(operation: Omit<Operation, 'id'>): Promise<void> {
    const { date, concept, employee, amount, paymentMethod, type } = operation;
    const query = 'INSERT INTO operations (date, concept, employee, amount, paymentMethod, type) VALUES (?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [date, concept, employee, amount, paymentMethod, type]);
}


export async function deleteOperation(id: string): Promise<void> {
  const query = 'DELETE FROM operations WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $operationServicePath -Value $operationServiceContent
Write-Host "  [OK] Archivo '$operationServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/providerService.ts ---
$providerServicePath = "src/services/providerService.ts"
$providerServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';

export interface Provider {
  id: number;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
}

export async function getProviders(): Promise<Provider[]> {
    try {
        const results = await executeQuery('SELECT * FROM providers');
        return JSON.parse(JSON.stringify(results)) as Provider[];
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createProvider(provider: Omit<Provider, 'id'>): Promise<void> {
    const { name, phone, email, address } = provider;
    const query = 'INSERT INTO providers (name, phone, email, address) VALUES (?, ?, ?, ?)';
    await executeQuery(query, [name, phone, email, address]);
}

export async function getProviderById(id: number): Promise<Provider | null> {
    const results = await executeQuery<Provider[]>('SELECT * FROM providers WHERE id = ?', [id]);
    if (results.length > 0) {
        return JSON.parse(JSON.stringify(results[0])) as Provider;
    }
    return null;
}

export async function updateProvider(id: number, provider: Partial<Omit<Provider, 'id'>>): Promise<void> {
    const { name, phone, email, address } = provider;
    const query = 'UPDATE providers SET name = ?, phone = ?, email = ?, address = ? WHERE id = ?';
    await executeQuery(query, [name, phone, email, address, id]);
}


export async function deleteProvider(id: number): Promise<void> {
  const query = 'DELETE FROM providers WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $providerServicePath -Value $providerServiceContent
Write-Host "  [OK] Archivo '$providerServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/reciboService.ts ---
$reciboServicePath = "src/services/reciboService.ts"
$reciboServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

export interface TestResult {
    studyName: string;
    result: string;
    reference: string;
}

export interface Recibo {
    id: number;
    createdBy: string;
    barcode: string;
    patientCode: string;
    patientName: string;
    contract?: string;
    subtotal: number;
    discount: number;
    total: number;
    paid: number;
    due: number;
    date: string;
    status: 'pending' | 'completed' | 'cancelled';
    studies: string[];
    packages: string[];
    doctor?: string;
    deliveryDate?: string;
    results?: TestResult[];
}

export type ReciboCreation = Omit<Recibo, 'id' | 'createdBy' | 'barcode' | 'date' | 'status'>;

export async function getRecibos(): Promise<Recibo[]> {
    try {
        const results = await executeQuery('SELECT * FROM recibos ORDER BY date DESC');
        const plainResults = JSON.parse(JSON.stringify(results)) as any[];
        return plainResults.map((row: any) => ({
            ...row,
            studies: JSON.parse(row.studies || '[]'),
            packages: JSON.parse(row.packages || '[]'),
            results: JSON.parse(row.results || '[]'),
        }));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createRecibo(reciboData: ReciboCreation): Promise<void> {
    const barcode = `BC-`$"{Date.now()}`;
    const date = new Date().toISOString();
    const status: Recibo['status'] = 'pending';
    const createdBy = 'admin'; // Debería venir del usuario logueado

    const {
        patientCode, patientName, contract, subtotal, discount, total, paid, due,
        studies, packages, doctor, deliveryDate
    } = reciboData;

    const query = `
        INSERT INTO recibos (
            createdBy, barcode, patientCode, patientName, contract, 
            subtotal, discount, total, paid, due, date, status, 
            studies, packages, doctor, deliveryDate
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
        createdBy, barcode, patientCode, patientName, contract,
        subtotal, discount, total, paid, due, date, status,
        JSON.stringify(studies), JSON.stringify(packages), doctor, deliveryDate
    ];

    await executeQuery(query, params);
}

export async function getReciboById(id: string): Promise<Recibo | null> {
     try {
        const results: any[] = await executeQuery('SELECT * FROM recibos WHERE id = ?', [id]);
        if (results.length > 0) {
            const row = JSON.parse(JSON.stringify(results[0]));
            return {
                ...row,
                studies: JSON.parse(row.studies || '[]'),
                packages: JSON.parse(row.packages || '[]'),
                results: JSON.parse(row.results || '[]')
            };
        }
        return null;
    } catch (error) {
        console.error("Database query failed:", error);
        return null;
    }
}

export async function saveResults(id: number, results: TestResult[]): Promise<void> {
    const query = 'UPDATE recibos SET results = ?, status = ? WHERE id = ?';
    await executeQuery(query, [JSON.stringify(results), 'completed', id]);
}
"@
Set-Content -Path $reciboServicePath -Value $reciboServiceContent
Write-Host "  [OK] Archivo '$reciboServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/studyService.ts ---
$studyServicePath = "src/services/studyService.ts"
$studyServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

export interface StudyParameter {
    name: string;
    unit: string;
    cost: number;
    factor: string;
    referenceType: string;
}

export interface IntegratedStudyRef {
    id: number;
    name: string;
}

export interface StudySample {
    type: string;
    container: string;
    indications: string;
    cost: number;
}

export interface Study {
    id: number;
    area: string;
    code: string;
    name: string;
    method: string;
    internalCost: number;
    deliveryTime: number;
    deliveryUnit: 'dias' | 'horas';
    processTime: string;
    processDays: string;
    isOutsourced: boolean;
    outsourcedLabId: string;
    outsourcedCode: string;
    outsourcedCost: number;
    outsourcedDeliveryTime: string;
    legend: string;
    scientificDescription: string;
    satServiceKey: string;
    satUnitKey: string;
    parameters: StudyParameter[];
    config: {
        showInRequest: boolean;
        canUploadDocuments: boolean;
        printLabSignature: boolean;
        printWebSignature: boolean;
        hasEnglishHeaders: boolean;
        printWithParams: boolean;
        generateWorkOrder: boolean;
    };
    hasSubStudies: boolean;
    isPackage: boolean;
    integratedStudies: IntegratedStudyRef[];
    synonyms: string[];
    samples: StudySample[];
    price: number;
    sampleType: string;
    category: string;
    shortcut: string;
}

export async function getStudies(): Promise<Study[]> {
    try {
        const results = await executeQuery('SELECT * FROM studies');
        const plainResults = JSON.parse(JSON.stringify(results)) as any[];
        return plainResults.map((row: any) => ({
            ...row,
            parameters: JSON.parse(row.parameters || '[]'),
            config: JSON.parse(row.config || '{}'),
            integratedStudies: JSON.parse(row.integratedStudies || '[]'),
            synonyms: JSON.parse(row.synonyms || '[]'),
            samples: JSON.parse(row.samples || '[]'),
        }));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createStudy(study: Omit<Study, 'id'>): Promise<void> {
    const query = `
        INSERT INTO studies (
            area, code, name, method, internalCost, deliveryTime, deliveryUnit,
            processTime, processDays, isOutsourced, outsourcedLabId, outsourcedCode,
            outsourcedCost, outsourcedDeliveryTime, legend, scientificDescription,
            satServiceKey, satUnitKey, parameters, config, hasSubStudies, isPackage,
            integratedStudies, synonyms, samples, price, sampleType, category, shortcut
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
        study.area, study.code, study.name, study.method, study.internalCost,
        study.deliveryTime, study.deliveryUnit, study.processTime, study.processDays,
        study.isOutsourced, study.outsourcedLabId, study.outsourcedCode, study.outsourcedCost,
        study.outsourcedDeliveryTime, study.legend, study.scientificDescription,
        study.satServiceKey, study.satUnitKey, JSON.stringify(study.parameters),
        JSON.stringify(study.config), study.hasSubStudies, study.isPackage,
        JSON.stringify(study.integratedStudies), JSON.stringify(study.synonyms),
        JSON.stringify(study.samples), study.internalCost, study.sampleType, study.area, study.code,
    ];
    await executeQuery(query, params);
}

export async function getStudyById(id: string): Promise<Study | null> {
    const results = await executeQuery('SELECT * FROM studies WHERE id = ?', [id]) as any[];
    if (results.length > 0) {
        const row = JSON.parse(JSON.stringify(results[0]));
        return {
            ...row,
            parameters: JSON.parse(row.parameters || '[]'),
            config: JSON.parse(row.config || '{}'),
            integratedStudies: JSON.parse(row.integratedStudies || '[]'),
            synonyms: JSON.parse(row.synonyms || '[]'),
            samples: JSON.parse(row.samples || '[]'),
        };
    }
    return null;
}

export async function updateStudy(id: string, study: Omit<Study, 'id'>): Promise<void> {
    const query = `
        UPDATE studies SET
            area = ?, code = ?, name = ?, method = ?, internalCost = ?, deliveryTime = ?,
            deliveryUnit = ?, processTime = ?, processDays = ?, isOutsourced = ?,
            outsourcedLabId = ?, outsourcedCode = ?, outsourcedCost = ?,
            outsourcedDeliveryTime = ?, legend = ?, scientificDescription = ?,
            satServiceKey = ?, satUnitKey = ?, parameters = ?, config = ?,
            hasSubStudies = ?, isPackage = ?, integratedStudies = ?, synonyms = ?,
            samples = ?, price = ?, sampleType = ?, category = ?, shortcut = ?
        WHERE id = ?
    `;
    const params = [
        study.area, study.code, study.name, study.method, study.internalCost,
        study.deliveryTime, study.deliveryUnit, study.processTime, study.processDays,
        study.isOutsourced, study.outsourcedLabId, study.outsourcedCode, study.outsourcedCost,
        study.outsourcedDeliveryTime, study.legend, study.scientificDescription,
        study.satServiceKey, study.satUnitKey, JSON.stringify(study.parameters),
        JSON.stringify(study.config), study.hasSubStudies, study.isPackage,
        JSON.stringify(study.integratedStudies), JSON.stringify(study.synonyms),
        JSON.stringify(study.samples), study.internalCost, study.sampleType, study.area, study.code,
        id
    ];
    await executeQuery(query, params);
}

export async function deleteStudy(id: string): Promise<void> {
  const query = 'DELETE FROM studies WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $studyServicePath -Value $studyServiceContent
Write-Host "  [OK] Archivo '$studyServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/cultureService.ts ---
$cultureServicePath = "src/services/cultureService.ts"
$cultureServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

interface Consumption {
    productId: string;
    quantity: number;
}

export interface Culture {
  id: number;
  category: string;
  name: string;
  sampleType: string;
  price: number;
  precautions: string;
  comments: string[];
  consumptions: Consumption[];
}

export async function getCultures(): Promise<Culture[]> {
    try {
        const results = await executeQuery<any[]>('SELECT * FROM cultures');
        const plainResults = JSON.parse(JSON.stringify(results));
        return plainResults.map((row: any) => ({
            ...row,
            comments: Array.isArray(row.comments) ? row.comments : JSON.parse(row.comments || '[]') as string[],
            consumptions: Array.isArray(row.consumptions) ? row.consumptions : JSON.parse(row.consumptions || '[]') as Consumption[],
        }));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createCulture(culture: Omit<Culture, 'id'>): Promise<void> {
    const { category, name, sampleType, price, precautions, comments, consumptions } = culture;
    const query = 'INSERT INTO cultures (category, name, sampleType, price, precautions, comments, consumptions) VALUES (?, ?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [category, name, sampleType, price, precautions, JSON.stringify(comments), JSON.stringify(consumptions)]);
}

export async function getCultureById(id: string): Promise<Culture | null> {
    const results = await executeQuery<any[]>('SELECT * FROM cultures WHERE id = ?', [id]);
     if (results.length > 0) {
        const row = JSON.parse(JSON.stringify(results[0]));
        return {
            ...row,
            comments: Array.isArray(row.comments) ? row.comments : JSON.parse(row.comments || '[]') as string[],
            consumptions: Array.isArray(row.consumptions) ? row.consumptions : JSON.parse(row.consumptions || '[]') as Consumption[],
        };
    }
    return null;
}

export async function updateCulture(id: string, culture: Omit<Culture, 'id'>): Promise<void> {
    const { category, name, sampleType, price, precautions, comments, consumptions } = culture;
    const query = 'UPDATE cultures SET category = ?, name = ?, sampleType = ?, price = ?, precautions = ?, comments = ?, consumptions = ? WHERE id = ?';
    await executeQuery(query, [category, name, sampleType, price, precautions, JSON.stringify(comments), JSON.stringify(consumptions), id]);
}


export async function deleteCulture(id: string): Promise<void> {
  const query = 'DELETE FROM cultures WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $cultureServicePath -Value $cultureServiceContent
Write-Host "  [OK] Archivo '$cultureServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/packageService.ts ---
$packageServicePath = "src/services/packageService.ts"
$packageServiceContent = @"
"use server";
import { executeQuery } from '@/lib/db';

export interface Package {
  id: number;
  name: string;
  shortcut: string;
  price: number;
  precautions: string;
  tests: string[];
  cultures: string[];
}

export async function getPackages(): Promise<Package[]> {
    try {
        const results = await executeQuery<any[]>('SELECT * FROM packages');
        const plainResults = JSON.parse(JSON.stringify(results));
        return plainResults.map(pkg => ({
            ...pkg,
            tests: Array.isArray(pkg.tests) ? pkg.tests : JSON.parse(pkg.tests || '[]'),
            cultures: Array.isArray(pkg.cultures) ? pkg.cultures : JSON.parse(pkg.cultures || '[]')
        }));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createPackage(pkg: Omit<Package, 'id'>): Promise<void> {
    const { name, shortcut, price, precautions, tests, cultures } = pkg;
    const query = 'INSERT INTO packages (name, shortcut, price, precautions, tests, cultures) VALUES (?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [name, shortcut, price, precautions, JSON.stringify(tests), JSON.stringify(cultures)]);
}

export async function getPackageById(id: number): Promise<Package | null> {
    const results = await executeQuery<any[]>('SELECT * FROM packages WHERE id = ?', [id]);
    if (results.length > 0) {
        const pkg = JSON.parse(JSON.stringify(results[0]));
        return {
            ...pkg,
            tests: Array.isArray(pkg.tests) ? pkg.tests : JSON.parse(pkg.tests || '[]') as string[],
            cultures: Array.isArray(pkg.cultures) ? pkg.cultures : JSON.parse(pkg.cultures || '[]') as string[]
        };
    }
    return null;
}

export async function updatePackage(id: number, pkg: Omit<Package, 'id'>): Promise<void> {
    const { name, shortcut, price, precautions, tests, cultures } = pkg;
    const query = 'UPDATE packages SET name = ?, shortcut = ?, price = ?, precautions = ?, tests = ?, cultures = ? WHERE id = ?';
    await executeQuery(query, [name, shortcut, price, precautions, JSON.stringify(tests), JSON.stringify(cultures), id]);
}


export async function deletePackage(id: number): Promise<void> {
  const query = 'DELETE FROM packages WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $packageServicePath -Value $packageServiceContent
Write-Host "  [OK] Archivo '$packageServicePath' actualizado." -ForegroundColor Cyan

# --- ARCHIVO: src/services/purchaseService.ts ---
$purchaseServicePath = "src/services/purchaseService.ts"
$purchaseServiceContent = @"
'use server';
import { executeQuery } from '@/lib/db';

interface PurchaseProduct {
    name: string;
    unitPrice: number;
    quantity: number;
    totalPrice: number;
}

interface PurchasePayment {
    date: string;
    amount: number;
    method: string;
}

export interface Purchase {
  id: number;
  date: string;
  branch: string;
  provider: string;
  notes: string;
  products: PurchaseProduct[];
  payments: PurchasePayment[];
  subtotal: number;
  tax: number;
  total: number;
  paid: number;
  due: number;
}

export async function getPurchases(): Promise<Purchase[]> {
    try {
        const results = await executeQuery<any[]>('SELECT * FROM purchases');
        const plainResults = JSON.parse(JSON.stringify(results));
        return plainResults.map((row: any) => ({
            ...row,
            products: JSON.parse(row.products || '[]'),
            payments: JSON.parse(row.payments || '[]'),
        }));
    } catch (error) {
        console.error("Database query failed:", error);
        return [];
    }
}

export async function createPurchase(purchase: Omit<Purchase, 'id'>): Promise<void> {
    const { date, branch, provider, notes, products, payments, subtotal, tax, total, paid, due } = purchase;
    const query = 'INSERT INTO purchases (date, branch, provider, notes, products, payments, subtotal, tax, total, paid, due) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
    await executeQuery(query, [date, branch, provider, notes, JSON.stringify(products), JSON.stringify(payments), subtotal, tax, total, paid, due]);
}

export async function getPurchaseById(id: string): Promise<Purchase | null> {
    const results = await executeQuery<any[]>('SELECT * FROM purchases WHERE id = ?', [id]);
     if (results.length > 0) {
        const row = JSON.parse(JSON.stringify(results[0]));
        return {
            ...row,
            products: JSON.parse(row.products || '[]'),
            payments: JSON.parse(row.payments || '[]'),
        };
    }
    return null;
}

export async function updatePurchase(id: string, purchase: Omit<Purchase, 'id'>): Promise<void> {
    const { date, branch, provider, notes, products, payments, subtotal, tax, total, paid, due } = purchase;
    const query = 'UPDATE purchases SET date = ?, branch = ?, provider = ?, notes = ?, products = ?, payments = ?, subtotal = ?, tax = ?, total = ?, paid = ?, due = ? WHERE id = ?';
    await executeQuery(query, [date, branch, provider, notes, JSON.stringify(products), JSON.stringify(payments), subtotal, tax, total, paid, due, id]);
}


export async function deletePurchase(id: string): Promise<void> {
  const query = 'DELETE FROM purchases WHERE id = ?';
  await executeQuery(query, [id]);
}
"@
Set-Content -Path $purchaseServicePath -Value $purchaseServiceContent
Write-Host "  [OK] Archivo '$purchaseServicePath' actualizado." -ForegroundColor Cyan

Write-Host "¡Proceso completado! Todos los archivos han sido actualizados." -ForegroundColor Green