export interface Study {
    id: number;
    nombre: string;
    descripcion: string;
    precio: number;
    categoria_nombre: string;
  }